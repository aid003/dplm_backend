import { getAccessToken, getRefreshToken, setTokens, clearTokens } from '@/shared/lib/auth'

const BASE_URL = 'http://localhost:8000/api'

type JsonLike = Record<string, unknown>

function withAuth(init: RequestInit | undefined, token: string): RequestInit {
  const headers = new Headers(init?.headers ?? {})
  if (token) headers.set('Authorization', `Bearer ${token}`)
  return { ...init, headers }
}

export async function apiFetch(input: string, init?: RequestInit): Promise<Response> {
  let res = await fetch(`${BASE_URL}${input}`, withAuth(init, getAccessToken()))
  if (res.status === 401 && getRefreshToken()) {
    const refreshRes = await fetch(`${BASE_URL}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken: getRefreshToken() }),
    })
    if (refreshRes.ok) {
      const tokens = (await refreshRes.json()) as { access_token: string; refresh_token: string }
      setTokens(tokens.access_token, tokens.refresh_token)
      res = await fetch(`${BASE_URL}${input}`, withAuth(init, getAccessToken()))
    } else {
      clearTokens()
    }
  }
  return res
}

export async function apiPost<TRequest extends JsonLike, TResponse>(path: string, body: TRequest): Promise<TResponse> {
  const res = await apiFetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    const message = (data as { message?: string })?.message ?? 'Request failed'
    throw new Error(message)
  }
  return data as TResponse
}



import Cookies from 'js-cookie'

export const TOKEN_KEYS = { access: 'access_token', refresh: 'refresh_token' } as const

export function setTokens(accessToken: string, refreshToken: string): void {
  Cookies.set(TOKEN_KEYS.access, accessToken, { sameSite: 'lax', secure: true, path: '/' })
  Cookies.set(TOKEN_KEYS.refresh, refreshToken, { sameSite: 'lax', secure: true, path: '/' })
}

export function clearTokens(): void {
  Cookies.remove(TOKEN_KEYS.access, { path: '/' })
  Cookies.remove(TOKEN_KEYS.refresh, { path: '/' })
}

export function getAccessToken(): string {
  return Cookies.get(TOKEN_KEYS.access) ?? ''
}

export function getRefreshToken(): string {
  return Cookies.get(TOKEN_KEYS.refresh) ?? ''
}



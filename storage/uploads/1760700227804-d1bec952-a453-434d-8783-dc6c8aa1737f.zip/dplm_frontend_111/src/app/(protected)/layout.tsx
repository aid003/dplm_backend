import type { ReactNode } from 'react'

export default function ProtectedLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-svh">
      <main className="container mx-auto p-6">{children}</main>
    </div>
  )
}



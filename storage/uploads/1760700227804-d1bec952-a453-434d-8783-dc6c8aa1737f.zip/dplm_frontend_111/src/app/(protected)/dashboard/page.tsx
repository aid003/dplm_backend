export default function DashboardPage() {
  return (
    <div className="grid gap-2">
      <h1 className="text-2xl font-semibold">Добро пожаловать в Dashboard</h1>
      <p className="text-muted-foreground">Вы успешно авторизованы.</p>
    </div>
  )
}


